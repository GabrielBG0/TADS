Segue o código para o trabalho, nessa pasta existe o arquivo Keys.js que fornece as chaves da aplicação
Segue tambem o repositório do código, mas sem as chaves: https://github.com/GabrielBG0/TADS/tree/master/Trab1/Spotify%20stats
Peso que logo que a avaliação for finalizada me avize para que possa gerar outro segredo para a aplicação