const clientId = "edd1c85333c04722b1a4326bc59420c0"
const clientSecret = "129f55c5b8574512a692477fe5e146e8"
const redirectUri = "http://localhost:3000/code/"

export { clientId, clientSecret, redirectUri }